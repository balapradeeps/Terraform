def lambda_handler(event, context):
  # Do some processing with the event

  # Return a response
    return {
    "statusCode": 200,
    "body": "Hello welcome to great kirikalan magic show from Lambda!"
}